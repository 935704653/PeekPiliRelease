# 安装python环境依赖

```shell
# windows
pip install -r spider/py/base/requirements.txt -i https://mirrors.cloud.tencent.com/pypi/simple
# linux
pip3 install --break-system-packages -r spider/py/base/requirements.txt -i https://mirrors.cloud.tencent.com/pypi/simple
```

# golang二进制文件

确保根目录下有 `binary/go_proxy` 里面有相应平台的二进制文件即可