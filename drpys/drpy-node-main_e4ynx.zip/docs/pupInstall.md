# pup安装说明书

pup(puppeteer) 是一款无头浏览器，可以模拟用户手动打开网页，通过一些网站的反爬机制

如需使用，可以通过下面命令安装

```shell
npx puppeteer browsers install chrome
```

注意，此东西目前只有pc和部分服务器支持安装和使用，手机上海阔不支持，此类源都不能使用
