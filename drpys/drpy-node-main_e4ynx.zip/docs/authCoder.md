# V我50支付凭证生成工具

1. 访问 http://localhost:5757/authcoder?len=10&number=1
2. 将生成的结果复制到加密工具，选择aes加密
3. 将加密后的结果放到凭证验证文件里
