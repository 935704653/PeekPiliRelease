# 压测说明

仅限windows设备上运行

1. 打开soft目录runnerGo_win_x64.exe
2. 使用谷歌浏览器访问 https://runnergo.apipost.cn/

根据页面提示进行接口并发能力和压力测试
