# 内置订阅地址

* [本地配置接口-静态](/index?pwd=$pwd)
* [远程订阅接口-全部](/config/1?sub=all&healthy=1&pwd=$pwd)
* [远程订阅接口-绿色](/config/1?sub=green&healthy=1&pwd=$pwd)
* [电视订阅接口-仅多媒体源](/config/1?sub=tv&healthy=1&pwd=$pwd)
* [电视订阅接口-仅网盘](/config/1?sub=pan&healthy=1&pwd=$pwd)
* [仅HIPY源](/config/1?sub=hipy&healthy=1&pwd=$pwd)

# 其他工具链接

* [道长专用git代理](https://gh-proxy.playdreamer.cn/)
