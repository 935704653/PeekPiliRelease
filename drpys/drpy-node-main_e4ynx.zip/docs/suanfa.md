# 关姐算法搭建说明

php7.3.3 + mysql5.7.4

php程序包，推荐通过1panel面板php7环境进行搭建。需要安装sg扩展如 `sg` `sg11`,`sg16` `pdo_mysql`