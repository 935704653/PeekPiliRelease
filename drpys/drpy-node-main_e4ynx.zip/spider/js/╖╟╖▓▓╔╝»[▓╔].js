/*
@header({
  searchable: 2,
  filterable: 0,
  quickSearch: 1,
  title: '非凡采集',
  '类型': '影视',
  lang: 'ds'
})
*/

var rule = {
    title: '非凡采集',
    模板: '采集1',
    host: 'http://ffzy5.tv',
    homeUrl: '/api.php/provide/vod',
    cate_exclude:'电影片|连续剧|综艺片',
    homeTid: 13,
}