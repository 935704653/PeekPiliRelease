/**
 * 影视TV 超連結跳轉支持
 * https://t.me/fongmi_offical/
 * https://github.com/FongMi/Release/tree/main/apk
@header({
  searchable: 2,
  filterable: 1,
  quickSearch: 0,
  title: '荐片',
  lang: 'ds'
})
*/
let imghost = '';

var rule = {
    title: '荐片',
    // host: 'http://api2.rinhome.com',
    //host: 'https://oiuzy.haitu33.com',
    host: 'https://dns.alidns.com/resolve?name=jpmobile.jianpiandns.com&type=TXT',
    hostJs: async function () {
        // let {HOST} = this;
        // log(HOST)
        // var html = await request(HOST, {headers: {"User-Agent": MOBILE_UA}});
        // let json = JSON.parse(html);
        // let data = json.Answer[0].data.replace(/'|"/g, '').split(',');
        // src = data[0];
        // if (!src.startsWith('http')) {
        //     src = 'https://' + src;
        // }
        // HOST = src
        // HOST = 'https://api.ubj83.com'
        HOST = ' https://api.ztcgi.com'
        imghost = `https://${JSON.parse((await req(`${HOST}/api/appAuthConfig`)).content).data.imgDomain}`;
        return HOST
    },
    // homeUrl: '/api/tag/hand?code=unknown601193cf375db73d&channel=wandoujia',//网站的首页链接,用于分类获取和推荐获取
    homeUrl: '/api/slide/list?pos_id=88',//网站的首页链接,用于分类获取和推荐获取
    // url:'/api/crumb/list?area=0&category_id=fyclass&page=fypage&type=0&limit=24&fyfilter',
    url: '/api/crumb/list?page=fypage&type=0&limit=24&fyfilter',
    class_name: '电影&电视剧&动漫&综艺',     // 筛选 /api/term/ad_fenlei?limit=10&page=1
    class_url: '1&2&3&4',
    // detailUrl: '/api/node/detail?channel=wandoujia&token=&id=fyid',//二级详情拼接链接(json格式用)
    detailUrl: '/api/video/detailv2?id=fyid',//二级详情拼接链接(json格式用)
    // searchUrl: '/api/video/search?key=**&page=fypage',
    searchUrl: '/api/v2/search/videoV2?key=**&category_id=88&page=fypage&pageSize=20',
    searchable: 2,
    quickSearch: 0,
    filterable: 1,
    filter: 'H4sIAAAAAAAAA+2V3UrDMBiG7yXHO2jTrtu8A69BPCiuqKhT6hTGGEzmxiY4f5CqWPBA3So4tsHE/aBX06T2Lsxc2mR2FWHzrId5vpA03/e8NA8EsLSSB1taDiwBVddUEAMZdUcjK2R20GmRrA/V7QPte1tmjMuWW7LGmCwEUIhRfPduD5sUiz62+y1ScRu3uN+mRelHEZ118OCDFhW/6HzUSZHiuI/d+2eGxaTP8fUTNl8oh6CwOi5MnpXTVJ171qBnjx7++iwoQNm7TEzxWPJwXOIx9LAg8lj0D0nyWPCwwlFyz4QmeJhkb2MwEegpgYq3c7oN+7t6lrUB1y/R8CzQBqfUcq+9NmzsZv1zP9vHqFqhBV3NbmbWWe/vetjo0NrBXlrNauObV2NEBGbXGsHLaW4Q1YrTHf0+CNZDt2HguhXQAZ1Y9rsZkAcZJqo1A23E1Rt7WKOYc+foHBcNitmQyQm4VPbnycysdjnOPtFpXqDByOOQ/0bnyufS1FCiyEWRW2zk4JyRg7MjJ8oh3jFPiG9ErGB7iSdEIY9zaXx9Q48G51WUiygX/5YLac5cSCG5SM32GQohPoizPf3Rocj/yP/F+i/P6b88238ohfgsh+Qi5H8Blcj/yP9/87/wBY9Rx63qDgAA',
    filter_url: 'area={{fl.area or "0"}}&sort={{fl.sort or "update"}}&year={{fl.year or "0"}}&category_id={{fl.cateId}}',
    filter_def: {
        0: {cateId: '0'},
        1: {cateId: '1'},
        2: {cateId: '2'},
        3: {cateId: '3'},
        4: {cateId: '4'}
    },
    // headers: {
    //     'User-Agent': 'jianpian-android/350',
    //     'JPAUTH': 'y261ow7kF2dtzlxh1GS9EB8nbTxNmaK/QQIAjctlKiEv'
    // },
    headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 9; V2196A Build/PQ3A.190705.08211809; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Mobile Safari/537.36;webank/h5face;webank/1.0;netType:NETWORK_WIFI;appVersion:416;packageName:com.jp3.xg3',
    },
    timeout: 5000,
    limit: 8,
    play_parse: true,
    lazy: async function (flag, id, flags) {
        // let {input} = this;
        // return {
        //     parse: 0,
        //     url: input,
        //     jx: 0
        // }

        return {
            parse: 0,
            url: id.indexOf(".m3u8") > -1?id:`tvbox-xg:${id}`
        }

    },
    parseList(html) {
        let res = JSON.parse(html);
        // console.log(res);

        return res.data.map(item => ({
            vod_id: item.jump_id || item.id,
            vod_name: item.title,
            vod_pic: `${imghost}${item.thumbnail}`,
            vod_remarks: item.mask,
            style: {"type": "rect", "ratio": 1.33}
        }))
},
    parseDetail(html) {
        let res = JSON.parse(html).data;
        let play_from = res.source_list_source.map(item => item.name).join('$$$').replace(/常规线路/g, '边下边播');
        let play_url = res.source_list_source.map(play =>
            play.source_list.map(({source_name, url}) => `${source_name}$${url}`).join('#')
        ).join('$$$');

        var vod = {
            "type_name": '',
            "vod_year": res.year,
            "vod_area": res.area,
            "vod_remarks": res.mask,
            "vod_content": res.description,
            "vod_play_from": play_from,
            "vod_play_url": play_url
        };

        return vod
    },

    推荐: async function () {
        let {input} = this;
        var d = [];
        var html = await request(input);
        // console.log(html);
        // html = JSON.parse(html).data[0].video;
        // html.forEach(it => {
        //     d.push({
        //         title: it.title,
        //         img: it.path + '@Referer=www.jianpianapp.com@User-Agent=jianpian-version353',
        //         desc: it.playlist.title + ' ⭐' + it.score,
        //         url: it.id
        //     })
        // });
        // return setResult(d);
        return this.parseList(html);
    },
    // 一级:'json:data;title;path;playlist.title;id',
    一级: async function (tid) {
        let {input, MY_PAGE} = this;
        tid = tid + '';
        if (tid.endsWith('_clicklink')) {
            tid = tid.split('_')[0];
            input = HOST + '/api/video/search?key=' + tid + '&page=' + +MY_PAGE;
        }
        var d = [];
        // https://api.ubj83.com/api/crumb/list?page=1&type=0&limit=24&area=0&sort=update&year=0&category_id=0
        // console.log('全部:',input);
        let html = await request(input);
        // console.log(html);
        html = JSON.parse(html).data;
        html.forEach(it => {
            d.push({
                title: it.title,
                // img: it.thumbnail || it.path,
                img: `${imghost}${it.thumbnail || it.path}`,
                desc: (it.mask || it.playlist.title) + ' ⭐' + it.score,
                url: it.id
            })
        });
        return setResult(d);
    },
    二级: async function () {
        let {input} = this;

        function getLink(data) {
            let link = data.map(it => {
                return '[a=cr:' + JSON.stringify({
                    'id': it.name + '_clicklink',
                    'name': it.name
                }) + '/]' + it.name + '[/a]'
            }).join(', ');
            return link
        }

        try {
            console.log(input);
            let html = await request(input);
            // console.log(html);
            return this.parseDetail(html);
            html = JSON.parse(html);
            let node = html.data;
            VOD = {
                vod_id: node.id,
                vod_name: node.title,
                vod_pic: node.thumbnail + '@Referer=www.jianpianapp.com@User-Agent=jianpian-version353',
                type_name: node.types[0].name,
                vod_year: node.year.title,
                vod_area: node.area.title,
                vod_remarks: node.score,
                vod_actor: getLink(node.actors),
                vod_director: getLink(node.directors),
                vod_content: node.description.strip()
            };
            if (typeof play_url === 'undefined') {
                var play_url = ''
            }
            let playMap = {};
            if (node.have_ftp_ur == 1) {
                playMap["边下边播超清版"] = node.new_ftp_list.map(it => {
                    return it.title + "$" + (/m3u8/.test(it.url) ? play_url + it.url : "tvbox-xg:" + it.url)
                }).join('#');
            }
            if (node.have_m3u8_ur == 1) {
                playMap["在线点播普清版"] = node.new_m3u8_list.map(it => {
                    return it.title + "$" + (/m3u8/.test(it.url) ? play_url + it.url : "tvbox-xg:" + it.url)
                }).join('#');
            }
            let playFrom = [];
            let playList = [];
            Object.keys(playMap).forEach(key => {
                playFrom.append(key);
                playList.append(playMap[key])
            });
            VOD.vod_play_from = playFrom.join('$$$');
            VOD.vod_play_url = playList.join('$$$');
            return VOD
        } catch (e) {
            log("获取二级详情页发生错误:" + e.message);
        }
    },
    // 搜索:'json:data;*;thumbnail;mask;*',
    搜索: async function () {
        let {input} = this;
        var d = [];
        let html = await request(input);
        return this.parseList(html);
        // html = JSON.parse(html).data;
        // html.forEach(it => {
        //     d.push({
        //         title: it.title,
        //         img: it.thumbnail,
        //         desc: it.mask + ' ⭐' + it.score,
        //         url: it.id
        //     })
        // });
        // return setResult(d);
    },
}
