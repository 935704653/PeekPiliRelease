/*
@header({
  searchable: 2,
  filterable: 0,
  quickSearch: 1,
  title: '极速资源[资]',
  '类型': '影视',
  lang: 'ds'
})
*/

var rule = {
    模板: '采集1',
    title: '极速资源[资]',
    host: 'https://jszyapi.com',
    cate_exclude: '电影片|连续剧|综艺片|动漫片|电影解说|演员|新闻资讯|电视剧|电影|综艺|动漫|伦理片',
    // parse_url: 'https://jisjiexi.com/play/?url='
    parse_url: ''
}