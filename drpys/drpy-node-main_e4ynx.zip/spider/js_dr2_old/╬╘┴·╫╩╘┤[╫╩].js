/*
@header({
  searchable: 2,
  filterable: 0,
  quickSearch: 1,
  title: '卧龙资源[资]',
  '类型': '影视',
  lang: 'ds'
})
*/

// https://collect.wolongzyw.com/api.php/provide/vod/?ac=list

var rule = {
    模板: '采集1',
    title: '卧龙资源[资]',
    host: 'https://collect.wolongzyw.com',
    // homeTid: '13',
    homeTid: '',
    cate_exclude: '电影片|连续剧|综艺片|动漫片|电影解说|体育|演员|新闻资讯',
    parse_url: '',
}