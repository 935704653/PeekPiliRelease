/*
@header({
  searchable: 2,
  filterable: 0,
  quickSearch: 0,
  title: '白嫖者联盟',
  '类型': '影视',
  lang: 'ds'
})
*/

var rule = {
    title: '白嫖者联盟',
    模板: '首图',
    host: 'https://www.qyzf88.com',
    url: '/qyvodshow/fyclass--------fypage---.html',
    searchUrl: '/qyvodsearch/**----------fypage---.html',
    searchable: 2,
    filterable: 0,
    class_parse: '.myui-header__menu li:gt(0):lt(5);a&&Text;a&&href;/(\\d+).html',
}